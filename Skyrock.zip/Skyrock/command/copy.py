const Discord = require('discord.js')

module.exports = {
    info: {
      name: "leave",
      description: "Leave le voc",
      usage: "skipto <number>",
      aliases: ["lv"],
    },
  
    run: async function (client, message, args) {
  
   if(message.guild === null)return;
  

    // Calculates ping between sending a message and editing it, giving a nice round-trip latency.
    // The second ping is an average latency between the bot and the websocket server (one-way, not round-trip)
        var VC = message.member.voice.channel;
  
        var newUserChannel = message.member.voice.channel;
 
        if (message.content.startsWith(">leave"))
        client.leaveVoiceChannel(message.member.voiceState.channelID);
    message.reply(`J'ai quitté le vocal !`)}
    }