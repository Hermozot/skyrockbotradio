const Discord = require('discord.js')

module.exports = {
    name: 'ping',
    description: 'ping du bot',
    async execute(client, message, args) {
     waiting = await message.reply(":ping_pong: Voici le ping du bot").catch(console.error);
        
        const embed = new Discord.MessageEmbed()
        .setAuthor("LATENCE DU BOT", + client.user.avatarURL())
        .setColor(0x0096ff)
.setThumbnail("https://cdn.discordapp.com/attachments/872036226402766870/878889436031647744/image0.png")
        .addField(`Latence de lˆhebergeur`,  `${waiting.createdTimestamp - message.createdTimestamp}` + "ms", true)
        .addField('Ping de L\'API', `${client.ws.ping} ms`)
         .setFooter("Demandé(e) par " + message.author.username, message.member.user.displayAvatarURL({dynamic:true}))
        .setTimestamp()
        
        waiting.edit(embed).catch(console.error);
    
    }}